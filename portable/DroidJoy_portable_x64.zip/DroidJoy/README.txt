----------------- Intsallation Instructions-----------------

1. Double click the "gamepad_config.reg" file
2. Click "Yes" in the message box
3. If it doesn't work just continue with the other steps

3. Open the "Gamepad driver" folder and execute "vJoySetup.exe"
4. In the installation dialog uncheck the "Companion Applications" checkbox
5. Click "Install"

6. Open "x64" folder
7. Open "DroidJoy Server" folder
8. Open the DroidJoy server application by clicking the "DroidJoyServer" exe file
(9. You can open the "DroidJoy Server" wherever you want)

-------------------------------------------------------------

If you encounter any problems or if you revceive any error messages contact me at
f.grill160@gmail.com

or at the DroidJoy facebook page
https://www.facebook.com/DroidJoy

For more informations regarding the game support visit
https://grill2010.github.io/droidJoy.html

